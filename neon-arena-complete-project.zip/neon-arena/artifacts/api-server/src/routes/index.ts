import { Router, type IRouter } from "express";
import healthRouter from "./health";
import runsRouter from "./runs";
import multiplayerRouter from "./multiplayer";

const router: IRouter = Router();

router.use(healthRouter);
router.use(runsRouter);
router.use(multiplayerRouter);

export default router;
